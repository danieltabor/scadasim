==================
performance module
==================
.. literalinclude:: ../../../examples/common/performance.py


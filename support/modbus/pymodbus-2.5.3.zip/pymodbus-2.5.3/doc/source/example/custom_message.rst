==================================================
Custom Message Example
==================================================
.. literalinclude:: ../../../examples/common/custom_message.py
==================================================
Modbus Scraper Example
==================================================
.. literalinclude:: ../../../examples/contrib/modbus_scraper.py
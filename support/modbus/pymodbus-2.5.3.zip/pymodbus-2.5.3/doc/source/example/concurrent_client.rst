==================================================
Concurrent Client Example
==================================================
.. literalinclude:: ../../../examples/contrib/concurrent_client.py
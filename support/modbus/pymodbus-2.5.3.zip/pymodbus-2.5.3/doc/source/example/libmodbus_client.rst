==================================================
Libmodbus Client Example
==================================================
.. literalinclude:: ../../../examples/contrib/libmodbus_client.py
==================================================
Modbus Payload Server Example
==================================================
.. literalinclude:: ../../../examples/common/modbus_payload_server.py
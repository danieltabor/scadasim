==================================================
Sunspec Client Example
==================================================
.. literalinclude:: ../../../examples/contrib/sunspec_client.py
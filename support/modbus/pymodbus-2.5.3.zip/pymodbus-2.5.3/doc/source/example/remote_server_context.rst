==================================================
Remote Server Context Example
==================================================
.. literalinclude:: ../../../examples/contrib/remote_server_context.py
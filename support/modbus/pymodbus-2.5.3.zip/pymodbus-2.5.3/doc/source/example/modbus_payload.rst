==================================================
Modbus Payload Example
==================================================
.. literalinclude:: ../../../examples/common/modbus_payload.py
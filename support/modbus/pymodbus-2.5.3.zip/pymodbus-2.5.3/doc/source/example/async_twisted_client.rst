==================================================
Async Twisted Client Example
==================================================
.. literalinclude:: ../../../examples/common/async_twisted_client.py
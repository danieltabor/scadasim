==================================================
Modbus Simulator Example
==================================================
.. literalinclude:: ../../../examples/contrib/modbus_simulator.py
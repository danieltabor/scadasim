==================================================
Synchronous Client Example
==================================================
.. literalinclude:: ../../../examples/common/synchronous_client.py
===========================
Asynchronous Server Example
===========================
.. literalinclude:: ../../../examples/common/asynchronous_server.py
